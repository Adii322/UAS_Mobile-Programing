class MyIcon {
  static const burnCaloriesIcon = "assets/icons/burn_calories_icon.svg";
  static const heartRateIcon = "assets/icons/heart_rate_icon.svg";
  static const stepsIcon = "assets/icons/step_icon.svg";
  static const oxygenIcon = "assets/icons/oxygen_icon.svg";
  static const pedometerIcon = "assets/icons/pedometer_icon.svg";
  static const cardioRespiratoryIcon = "assets/icons/cardiorespiratory_icon.svg";
  static const metsIcon = "assets/icons/mets_icon.svg";
  static const maxHeartRateIcon = "assets/icons/max_heart_rate_icon.svg";
  static const homeIcon = "assets/icons/home_icon.svg";
  static const profileIcon = "assets/icons/profile_icon.svg";
  static const targetIcon = "assets/icons/target_icon.svg";
  static const deviceIcon = "assets/icons/device_icon.svg";
  static const challengeIcon = "assets/icons/challenge_icon.svg";
  static const historyIcon = "assets/icons/history_icon.svg";
}
