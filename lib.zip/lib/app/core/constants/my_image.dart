class MyImage {
  static const onboardingBlobImage = "assets/images/onboarding_blob.png";
  static const authBlobImage = "assets/images/auth_blob.png";
  static const aboutUsImage = "assets/images/about_us_image.jpg";
}