import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shimmer/shimmer.dart';
import 'package:young_care/app/common/controller/bluetooth_controller.dart';
import 'package:young_care/app/core/constants/my_icon.dart';
import 'package:young_care/app/data/models/pedometer_result.dart';
import 'package:young_care/app/data/models/resource.dart';
import 'package:young_care/app/modules/home/widgets/heart_rate_card.dart';
import 'package:young_care/app/modules/home/widgets/home_tile.dart';
import 'package:young_care/app/modules/home/widgets/step_progress_card.dart';

import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0XFFF2F2F2),
      body: RefreshIndicator(
        onRefresh: controller.refreshAll,
        color: Color(0XFFF0A5443),
        child: SingleChildScrollView(
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 20),
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 24,
                        backgroundImage: NetworkImage(
                          'https://i.pravatar.cc/300',
                        ),
                      ),
                      SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Hi, ${controller.userController.user.value?.name.split(' ').first ?? ''}!',
                            style: GoogleFonts.lexendDeca(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          Text(
                            '"Lorem ipsum dolor sit amet”',
                            style: TextStyle(
                              fontSize: 10,
                              color: Color(0XFF6F7D7D),
                            ),
                          ),
                        ],
                      ),
                      Spacer(),
                      Icon(Icons.notifications, size: 28),
                    ],
                  ),
                  SizedBox(height: 20),
                  Obx(() {
                    final Resource<PedometerResult> state =
                        controller.todayPedometer.value;
                    final pedometer = state.data;
                    final errorMessage = state.hasError
                        ? state.message ?? 'Failed to load'
                        : null;

                    if (state.isLoading) {
                      return Shimmer.fromColors(
                        baseColor: Colors.grey[300]!,
                        highlightColor: Colors.grey[100]!,
                        child: HeartRateCard(
                        isLoading: state.isLoading,
                        heartRate: pedometer?.heartRate,
                        errorMessage: errorMessage,
                                            ),
                      );
                    }
                    return HeartRateCard(
                      isLoading: state.isLoading,
                      heartRate: pedometer?.heartRate,
                      errorMessage: errorMessage,
                    );
                  }),
                  SizedBox(height: 10),
                  Obx(() {
                    final Resource<int> state = controller.todaySteps.value;
                    final user = controller.userController.user.value;
                    return StepProgressCard(
                      isLoading: state.isLoading,
                      steps: state.data,
                      dailyTarget: user?.dailyTargetStep,
                      errorMessage: state.hasError ? state.message : null,
                    );
                  }),
                  SizedBox(height: 20),
                  Text(
                    "Today's Progress",
                    style: GoogleFonts.lexendDeca(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 10),
                  Obx(() {
                    final Resource<int> state = controller.todaySteps.value;
                    final bool isLoading = state.isLoading;
                    final bool hasError = state.hasError;
                    final int steps = state.data ?? 0;
                    String value;
                    String? unit = 'steps';

                    if (isLoading) {
                      value = 'Loading...';
                      unit = null;
                    } else if (hasError) {
                      value = state.message ?? 'Failed to load';
                      unit = null;
                    } else {
                      value = _formatNumber(steps);
                      if (steps <= 0) {
                        unit = null;
                      }
                    }

                    return HomeTile(
                      label: "Steps",
                      unit: unit,
                      value: value,
                      icon: SvgPicture.asset(MyIcon.stepsIcon),
                    );
                  }),
                  SizedBox(height: 10),
                  Obx(() {
                    final Resource<PedometerResult> state =
                        controller.todayPedometer.value;
                    final pedometer = state.data;
                    final isLoading = state.isLoading;
                    final hasError = state.hasError;

                    String value;
                    String? unit;

                    if (isLoading) {
                      value = 'Loading...';
                      unit = null;
                    } else if (hasError) {
                      value = state.message ?? 'Failed to load';
                      unit = null;
                    } else if (pedometer?.burnCalories != null) {
                      value = pedometer!.burnCalories!.toStringAsFixed(0);
                      unit = 'kcal';
                    } else {
                      value = 'No record today';
                      unit = null;
                    }

                    if (isLoading) {
                      return Shimmer.fromColors(
                        baseColor: Colors.grey[300]!,
                        highlightColor: Colors.grey[100]!,
                        child: HomeTile(
                          label: "Burn Calories",
                          unit: unit,
                          value: value,
                          icon: SvgPicture.asset(MyIcon.burnCaloriesIcon),
                        ),
                      );
                    }

                    return HomeTile(
                      label: "Burn Calories",
                      unit: unit,
                      value: value,
                      icon: SvgPicture.asset(MyIcon.burnCaloriesIcon),
                    );
                  }),
                  SizedBox(height: 10),
                  Obx(() {
                    final Resource<PedometerResult> state =
                        controller.todayPedometer.value;
                    final pedometer = state.data;
                    final isLoading = state.isLoading;
                    final hasError = state.hasError;

                    String value;
                    String? unit;

                    if (isLoading) {
                      value = 'Loading...';
                      unit = null;
                    } else if (hasError) {
                      value = state.message ?? 'Failed to load';
                      unit = null;
                    } else if (pedometer?.heartRate != null) {
                      value = pedometer!.heartRate!.toString();
                      unit = 'bpm';
                    } else {
                      value = 'No record today';
                      unit = null;
                    }

                    if (isLoading) {
                      return Shimmer.fromColors(
                        baseColor: Colors.grey[300]!,
                        highlightColor: Colors.grey[100]!,
                        child: HomeTile(
                        label: "Heart Rate",
                        unit: unit,
                        value: value,
                        icon: SvgPicture.asset(MyIcon.heartRateIcon),
                                            ),
                      );
                    }

                    return GestureDetector(
                      onTap: () async {
                        Get.log("Minta");
                        final service = Get.find<BluetoothController>();
                        await service.requestVitalSigns();
                        Get.log("Selesai");
                      },
                      child: HomeTile(
                        label: "Heart Rate",
                        unit: unit,
                        value: value,
                        icon: SvgPicture.asset(MyIcon.heartRateIcon),
                      ),
                    );
                  }),
                  SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  String _formatNumber(int value) {
    final String digits = value.abs().toString();
    final StringBuffer buffer = StringBuffer();

    for (int index = 0; index < digits.length; index++) {
      final int positionFromEnd = digits.length - index;
      buffer.write(digits[index]);
      if (positionFromEnd > 1 && positionFromEnd % 3 == 1) {
        buffer.write('.');
      }
    }

    final String formatted = buffer.toString();
    return value < 0 ? '-$formatted' : formatted;
  }
}
